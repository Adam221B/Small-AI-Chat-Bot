import json
import random
import nltk
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

nltk.download('punkt')
nltk.download('wordnet')

lemmatizer = WordNetLemmatizer()

# Load intents
with open('intents.json', encoding='utf-8') as f:
    intents = json.load(f)

# Prepare data
X = []
y = []
for intent in intents['intents']:
    for pattern in intent['patterns']:
        tokens = nltk.word_tokenize(pattern)
        tokens = [lemmatizer.lemmatize(word.lower()) for word in tokens if word.isalnum()]
        X.append(' '.join(tokens))
        y.append(intent['tag'])

# Vectorize
vectorizer = CountVectorizer()
X_vec = vectorizer.fit_transform(X)

# Train classifier
clf = MultinomialNB()
clf.fit(X_vec, y)

# Chat function
def chat():
    print("Type 'quit' to exit.")
    while True:
        inp = input("You: ")
        if inp.lower() == 'quit':
            break
        tokens = nltk.word_tokenize(inp)
        tokens = [lemmatizer.lemmatize(word.lower()) for word in tokens if word.isalnum()]
        inp_vec = vectorizer.transform([' '.join(tokens)])
        pred = clf.predict(inp_vec)[0]
        for intent in intents['intents']:
            if intent['tag'] == pred:
                print("Bot:", random.choice(intent['responses']))

chat()